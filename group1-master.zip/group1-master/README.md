# group1

-----------------------------------------

# Group Members:

Essex, Andrew - aessex@uccs.edu

Clark, Jeremy - jclark14@uccs.edu

Medina, Julian - jmedina5@uccs.edu

Moore, Joshua - jmoore9@uccs.edu

Troutman, Nicholas - ntroutma@uccs.edu

Griebenow, Ryan - rgrieben@uccs.edu

-----------------------------------------
 
 # Our Current Heroku Deployment:
 
 https://intense-dawn-61832.herokuapp.com/
 
-----------------------------------------
 