class TrackerController < ApplicationController
  
  def index
    @items = Item.all
  end
  
end
