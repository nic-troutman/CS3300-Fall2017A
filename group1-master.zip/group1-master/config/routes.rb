Rails.application.routes.draw do
  root      'tracker#index'
  get       'tracker/index'
  get       'tracker/new'
  get       'tracker/index_0'

  get       '/login',   to: 'sessions#new'
  post      '/login',   to: 'sessions#create'
  delete    '/logout',  to: 'sessions#destroy'
  get       '/signup',  to: 'users#new'
  post      '/signup',  to: 'users#create'
  resources :users
  
  get       '/new_item',  to: 'items#new'
  post      '/new_item',  to: 'items#create'
  resources :items
  
end
