Given(/^I am on the My Item List page with my new item$/) do
        visit root_path
        page.should have_content('My Items')
        click_on('Add item')
        page.should have_content('Name' && 'Link' && 'Target price')
        fill_in 'Name', with: 'Cool Item'
        fill_in 'Link', with: 'www.test.com'
        fill_in 'Target price', with: '100'
        click_button 'Add Item'
        # aggregate of previous test; ensures we have a test item to work with
end
Then(/^I should see each item’s price pulled from a few different websites$/) do
        page.should have_content('My Items')
        page.should have_content('Cool Item' && '100')
        page.should have_content('74.99')
        # after implementing actual pulls, we will have more than just this hardcoded value
end

Then(/^I should see the lowest price highlighted if it is lower than my target price$/) do
        pending # Cannot be tested until we pull the price from a url
        # this will require comparing prices, and then verifying that a css highlight was applied via the controller
end
