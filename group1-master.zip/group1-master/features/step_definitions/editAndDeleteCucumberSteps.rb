Given(/^I am on the Home Page$/) do
   pending
end
When(/^I click on an item$/) do
   pending
end
Then(/^I should be on the Edit Item page$/) do
   pending
end
When(/^I edit an item's information$/) do
   pending
end
And(/^I click Update Item$/) do
   pending
end
Then(/^I should be back on the Home Page$/) do
   pending
end
And(/^I should see my edited item$/) do
   pending
end
When(/^I click on the Edit Item page$/) do
   pending
end
And(/^I click on the Delete button$/) do
   pending
end
Then(/^I should be back on the Home Page$/) do
   pending
end
And(/^I should not see the item I deleted$/) do
   pending
end
