Given(/^I am anywhere on the site$/) do
       visit root_path
       page.should have_content('Price Tracker 5000')
end

Then(/^I should be able to login in with a email and password$/) do
        visit root_path
       click_on('Log In')
       email = 'test@gmail.com'
       password = 'test1234'
       name = 'jane doe'

       page.should have_content('Email' && "Password")
       click_on('Sign up here')
       fill_in 'Name', :with => name
       fill_in 'Email', :with => email
       fill_in 'Password', :with => password
       fill_in 'Confirmation', :with => password
       click_on('Create my account')
       expect(page).to have_text('jane doe' && 'test@gmail.com ')
end
Then(/^I should be on the My Item List page$/) do
       visit root_path
end 
And(/^I should see my saved items/) do
   page.should have_content('Price Tracker 5000')
end