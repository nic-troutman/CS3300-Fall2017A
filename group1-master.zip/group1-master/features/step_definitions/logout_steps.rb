Given(/^I Am currently logged in$/) do
  email = 'test@gmail.com'
  password = 'test1234'
  name = 'jane doe'
 
  visit root_path
  click_on('Log In')
  page.should have_content('Email' && "Password")
  click_on('Sign up here')
  fill_in 'Name', :with => name
  fill_in 'Email', :with => email
  fill_in 'Password', :with => password
  fill_in 'Confirmation', :with => password
  click_on('Create my account')
  expect(page).to have_text('jane doe' && 'test@gmail.com ')
end

Then(/^I should be able to logout of my account$/) do
        visit root_path
        click_link("Log Out")
end
And(/^I should be on the price tracker 5000 homepage/) do
   page.should have_content('Price Tracker 5000')
end