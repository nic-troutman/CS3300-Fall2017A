Given(/I am on the index page$/) do
       visit root_path
       page.should have_content('Price Tracker 5000')
end

Then(/^I should be able to signup with a email and password$/) do
       email = 'test@gmail.com'
       password = 'test1234'
       name = 'jane doe'
       
       visit root_path
       click_on('Log In')
       page.should have_content('Email' && "Password")
       click_on('Sign up here')
       fill_in 'Name', :with => name
       fill_in 'Email', :with => email
       fill_in 'Password', :with => password
       fill_in 'Confirmation', :with => password
       click_on('Create my account')
       expect(page).to have_text('jane doe' && 'test@gmail.com ')
end
Then(/^I will be on the user page$/) do
       visit root_path
end 
And(/^I should see user items$/) do
   page.should have_content('Price Tracker 5000')
end