Given(/^I have created a listing and target price$/) do
        visit root_path
        page.should have_content('My Items')
        click_on('Add item')
        page.should have_content('Name' && 'Link' && 'Target price')
        fill_in 'Name', with: 'Cool Item'
        fill_in 'Link', with: 'www.test.com'
        fill_in 'Target price', with: '100'
        click_button 'Add Item'
end

Then(/^prices should automatically be checked periodically$/) do
        pending # cannot be tested until prices are actually pulled
        # prices are pulled on loading the page
end

When(/^a price dips to or below my target price$/) do
        pending # cannot be tested until prices are pulled
        # pulled prices are compared to target price
        # if a price is lower, checks to see if the appropriate css highlight has been applied
end

Then(/^I should receive an email letting me know$/) do
        pending
end
