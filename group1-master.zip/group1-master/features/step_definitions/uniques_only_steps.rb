Given(/^I am on My Item List page$/) do
  pending
end
When(/^I click the “Add new item” button$/) do
  pending
end
Then(/^I should be on the Add New Item page$/) do
  pending
end
When(/^I fill out the info that is exactly the same as another item's info$/) do
  pending
end
And(/^I press “Add item” button$/) do
  pending
end
Then(/^I should be on the My Item Lists page$/) do
  pending
end
And(/^I should not see my new listing$/) do
  pending
end
