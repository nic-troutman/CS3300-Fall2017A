require 'rails_helper'

RSpec.describe "items/edit.html.erb", type: :view do
  @item = Item.new(:name => "Item", :link => "Test Link", => :target_price => 40)
end
